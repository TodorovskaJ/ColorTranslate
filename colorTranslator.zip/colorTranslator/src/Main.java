import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        HashMap <String ,String> colorTranslator = new HashMap<>();
        colorTranslator.put("Crvena","Red");
        colorTranslator.put("Zolta","Yellow");
        colorTranslator.put("Sina","Blue");
        colorTranslator.put("Zelena","Green");
        colorTranslator.put("Violetova","Purple");
        colorTranslator.put("Portokalova","Orange");
        colorTranslator.put("Bela","White");
        colorTranslator.put("Crna","Black");
        colorTranslator.put("Kafena","Brown");
        colorTranslator.put("Rozeva","Pink");
        colorTranslator.put("Siva","Grey");

        HashMap <String ,String> colorTranslator1 = new HashMap<>();
        colorTranslator.put("Red","Crvena");
        colorTranslator.put("Yellow","Zolta");
        colorTranslator.put("Blue","Sina");
        colorTranslator.put("Green","Zelena");
        colorTranslator.put("Purple","Violetova");
        colorTranslator.put("Orange","Portokalova");
        colorTranslator.put("White","Bela");
        colorTranslator.put("Black","Crna");
        colorTranslator.put("Brown","Kafena");
        colorTranslator.put("Pink","Rozeva");
        colorTranslator.put("Grey","Siva");

        Scanner scanner = new Scanner(System.in);
        System.out.println("Prevod na boi / Color translator");
        System.out.println("Vnesete boja za prevod / Insert color for translate ");
        String color = scanner.nextLine();
        if(colorTranslator.containsKey(color)){
            System.out.println("Translate from Macedonian to English: " + color + " - " + colorTranslator.get(color));
        } else if (colorTranslator1.containsKey(color)) {
            System.out.println("Translate from English to Macedonian: " + color + " - " + colorTranslator1.get(color));
        } else {
            System.out.println("Ne postoi takva boja! / The color does not exist!");
        }
    }
}